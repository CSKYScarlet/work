# 1
# 입력 갯수
N = 5
# 합
sum_value = 0
# 평균
arage_value = 0

for value in range(N):
    # 입력메시지 출력 & 입력받기
    msg = str(value + 1) + "번째 값 입력"
    input_value = int(input(msg))
    # 합
    sum_value += input_value
# 평균
arage_value = sum_value / N
# 출력
print("합계 :", sum_value)
print("평균 :", arage_value)