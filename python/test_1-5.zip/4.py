# 4
# 범위 값 지정
N = 100
# # 리스트를 저장할 변수
# n_list = []
# # 1 ~ 100 순환
# for value in range(N):
#     # 현재 값을 문자형으로 저장
#     n_list.append(str(value + 1))
#     # 현재 값 문자순환
#     for subvalue in n_list[value]:
#         # 3 매칭 시 출력 후탈출
#         if subvalue == "3":
#             print(n_list[value])
#             break

# 리스트 제거식
for value in range(N):
    for subvalue in str(value + 1):
        if subvalue == "3":
            print(value + 1)
            break