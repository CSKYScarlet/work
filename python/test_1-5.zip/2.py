# 2
while True: # 반복
    # 정수를 입력받기
    input_value = int(input("정수를 입력 하세요"))
    # 양수일 경우 출력
    if input_value > 0:
        print("양수 입니다.")
    # 음수일 경우 출력
    elif input_value < 0:
        print("음수 입니다.")
    # 0일 시 종료
    else:
        break