# 3

# 층 값
N = 5

# 세로
for value in range(N):
    # 가로 빈칸
    for air in range(value):
        print(" ", end="")
    # 가로 별
    for subvalue in range(N - value):
        print("*", end="")
    # 줄넘기기
    print("")