# 5
# 문자열 지정
myList = "!! hello world, it is awesome day."
p_word = 0
word = 0
words = 0
# 문자열 순환
for value in myList:
    # 조건문에 따라 카운트
    #특수문자
    if value == "!" or value == "." or value == ",":
        p_word += 1
    # 단어
    elif value == " ":
        words += 1 
    # 일반 문자
    else:
        word += 1
# 출력
print("특수문자 수 :", p_word)
print("단어 수 :", words)
print("특수문자 제외 글자 수 :", word)