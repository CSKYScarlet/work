import turtle
# 터틀 저장
t = turtle.Turtle()

# 반복해서 그리기
for value in range(6):# 6각형
    t.right(60)# 오른쪽 60도 회전
    t.forward(100)# 전진